// Digitale klok bijwerken
function updateClock() {
  const clockElement = document.getElementById('digital-clock');
  if (clockElement) {
    const now = new Date();
    const hours = String(now.getHours()).padStart(2, '0');
    const minutes = String(now.getMinutes()).padStart(2, '0');
    const seconds = String(now.getSeconds()).padStart(2, '0');
    clockElement.textContent = `${hours}:${minutes}:${seconds}`;
  }
}
setInterval(updateClock, 1000);
updateClock();

// Thema-wisselaar functionaliteit
document.addEventListener('DOMContentLoaded', () => {
  const themeToggle = document.getElementById('theme-toggle');
  const body = document.body;

  // Controleer eerder opgeslagen thema
  if (localStorage.getItem('theme') === 'dark') {
    body.classList.add('dark-mode');
    if (themeToggle) themeToggle.checked = true;
  }

  if (themeToggle) {
    themeToggle.addEventListener('change', () => {
      if (themeToggle.checked) {
        body.classList.add('dark-mode');
        localStorage.setItem('theme', 'dark');
      } else {
        body.classList.remove('dark-mode');
        localStorage.setItem('theme', 'light');
      }
    });
  }
});

// Hamburger menu functionaliteit
document.addEventListener('DOMContentLoaded', () => {
  const hamburgerBtn = document.getElementById('hamburger-btn');
  const hamburgerLinks = document.querySelector('.hamburger-links');

  if (hamburgerBtn && hamburgerLinks) {
    hamburgerBtn.addEventListener('click', () => {
      hamburgerLinks.classList.toggle('hidden');
    });
  }
});

// Cookie banner functionaliteit
document.addEventListener('DOMContentLoaded', () => {
  const cookieBanner = document.getElementById('cookie-banner');
  const acceptCookiesButton = document.getElementById('accept-cookies');

  if (localStorage.getItem('cookiesAccepted') && cookieBanner) {
    cookieBanner.style.display = 'none';
  }

  if (acceptCookiesButton) {
    acceptCookiesButton.addEventListener('click', () => {
      localStorage.setItem('cookiesAccepted', 'true');
      if (cookieBanner) {
        cookieBanner.style.display = 'none';
      }
    });
  }
});

// Dynamische begroeting
document.addEventListener("DOMContentLoaded", () => {
  function getGreeting() {
    const now = new Date();
    const hour = now.getHours();

    if (hour >= 6 && hour < 12) {
      return "Goedemorgen";
    } else if (hour >= 12 && hour < 18) {
      return "Goedemiddag";
    } else if (hour >= 18 && hour < 24) {
      return "Goedenavond";
    } else {
      return "Goedenacht";
    }
  }

  const greetingElement = document.getElementById("greeting");
  if (greetingElement) {
    greetingElement.textContent = getGreeting();
  }
});

// Set the date we're counting down to
var countDownDate = new Date("Feb 9, 2025 00:00:01").getTime();

// Update the count down every 1 second
var x = setInterval(function() {

  // Get today's date and time
  var now = new Date().getTime();
    
  // Find the distance between now and the count down date
  var distance = countDownDate - now;
    
  // Time calculations for days, hours, minutes and seconds
  var days = Math.floor(distance / (1000 * 60 * 60 * 24));
  var hours = Math.floor((distance % (1000 * 60 * 60 * 24)) / (1000 * 60 * 60));
  var minutes = Math.floor((distance % (1000 * 60 * 60)) / (1000 * 60));
  var seconds = Math.floor((distance % (1000 * 60)) / 1000);
    
  // Output the result in an element with id="demo"
  document.getElementById("demo").innerHTML = days + "d " + hours + "h "
  + minutes + "m " + seconds + "s ";
    
  // If the count down is over, write some text 
  if (distance < 0) {
    clearInterval(x);
    document.getElementById("demo").innerHTML = "EXPIRED";
  }
}, 1000);